const paka = (urlRoot = '/', tokens = new Set(), h = Object.create(null)) => Object.assign(h, {
    async get(file) {
        return await fetch(urlRoot + file + '?tk=' + h.takeToken())
    },
    async post(file, data, fetchOptions = {}) {
        return await fetch(urlRoot + file + '?tk=' + h.takeToken(), Object.assign(fetchOptions, {
            method: 'POST',
            body: data
        }))
    },
    async delete(file) {
        return await fetch(urlRoot + file + '?tk=' + h.takeToken(), {
            method: 'DELETE'
        })
    },
    takeToken() {
        const token = tokens.values().next().value;
        if (tokens.delete(token)) return token
    },
    tokenate(url) {
        return `${url}?tk=${h.takeToken()}`
    },
    feed(...tkns) {
        tokens.add(...tkns)
    }
})
paka.fromTokens = (...tkns) => (urlRoot = '/') => paka(urlRoot, new Set(tkns))
export default paka